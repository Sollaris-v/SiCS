package com.example.sics.model;

import com.example.sics.config.ConfiguracaoFirebase;
import com.example.sics.helper.Base64Custom;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class Chamado {

    private String idChamado;
    private String dataAbertura;
    private String dataFechamento;
    private String descricaoCli;
    private String descricaoFunc;
    private String sastifacao;
    private String idCliente;
    private String idFuncionario;
    private String especialidade;
    private String estado;
    private String titulo;
    private String tipo;

    public Chamado() {

    }

    FirebaseAuth autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
    String idUsuario = Base64Custom.codificarBase64(autenticacao.getCurrentUser().getEmail());

    public void salvar(){
        DatabaseReference firebase = ConfiguracaoFirebase.getFirebaseDatabase();
        firebase.child("chamados")
                .child(idUsuario)
                .push()
                .setValue(this);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }


    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    public String getIdChamado() {
        return idChamado;
    }

    public void setIdChamado(String idChamado) {
        this.idChamado = idChamado;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getDataFechamento() {
        return dataFechamento;
    }

    public void setDataFechamento(String dataFechamento) {
        this.dataFechamento = dataFechamento;
    }

    public String getDescricaoCli() {
        return descricaoCli;
    }

    public void setDescricaoCli(String descricaoCli) {
        this.descricaoCli = descricaoCli;
    }

    public String getDescricaoFunc() {
        return descricaoFunc;
    }

    public void setDescricaoFunc(String descricaoFunc) {
        this.descricaoFunc = descricaoFunc;
    }

    public String getSastifacao() {
        return sastifacao;
    }

    public void setSastifacao(String sastifacao) {
        this.sastifacao = sastifacao;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(String idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
