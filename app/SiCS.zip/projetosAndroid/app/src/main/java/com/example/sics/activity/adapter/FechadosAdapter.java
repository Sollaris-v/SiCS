package com.example.sics.activity.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sics.R;
import com.example.sics.model.Chamado;

import java.util.List;

public class FechadosAdapter extends RecyclerView.Adapter<FechadosAdapter.MyViewHolder> {

    private List<Chamado> fechados;
    private Context context;


    public FechadosAdapter(List<Chamado> lista, Context c) {
        this.fechados = lista;
        this.context = c;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_chamado, parent, false);
        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Chamado chamado = fechados.get(position);

        holder.titulo.setText( chamado.getTitulo());
        holder.tipo.setText( chamado.getTipo());
        //holder.data.setText(chamado.getDataAbertura());
        //holder.data.setText(chamado.getIdCliente());



    }

    @Override
    public int getItemCount() {
        return fechados.size();
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder {

        TextView titulo, tipo, data, autor;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            titulo = itemView.findViewById(R.id.textTitulo);
            tipo = itemView.findViewById(R.id.textTipo);
            data = itemView.findViewById(R.id.textData);
            autor = itemView.findViewById(R.id.textAutor);
        }
    }


}
