package com.example.sics.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sics.R;
import com.example.sics.helper.DateCustom;
import com.example.sics.model.Chamado;

public class AbrirChamadoActivity extends AppCompatActivity {

    private EditText  campoTitulo, campoDescricao;
    private Spinner campoTipo;
    private Button botaoEnviar, botaoVoltar;
    private Chamado chamado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abrir_chamado);

        campoTitulo = findViewById(R.id.editTitulo);
        campoTipo = findViewById(R.id.spinnerTipo);
        campoDescricao = findViewById(R.id.editDescricao);

        botaoEnviar = findViewById(R.id.botaoEnviar);
        botaoVoltar = findViewById(R.id.botaoVoltar);

        carregarDadosSpinner();

        botaoEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String textoTitulo = campoTitulo.getText().toString();
                String textoTipo = campoTitulo.getText().toString();
                String textoDescricao = campoDescricao.getText().toString();

                //VERIFICA SE HA CAMPOS VAZIOS

                if (!textoTitulo.isEmpty()) {
                    if (!textoTipo.isEmpty()) {
                        if (!textoDescricao.isEmpty()) {

                            String dataAtual = DateCustom.dataAtual();

                            chamado = new Chamado();
                            chamado.setTitulo(campoTitulo.getText().toString());
                            chamado.setTipo(campoTipo.getSelectedItem().toString());
                            chamado.setDescricaoCli(campoDescricao.getText().toString());
                            chamado.setDataAbertura(dataAtual);
                            chamado.setEstado("Aberto");

                            chamado.salvar();

                            Toast.makeText(AbrirChamadoActivity.this, "Chamado enviado!", Toast.LENGTH_SHORT).show();

                            finish();


                                        /*
                                        chamado = new Chamado();
                                        chamado.setTitulo(textoTitulo);
                                        chamado.setTipo(textoTipo);
                                        chamado.setDescricaoCli(textoDescricao);
                                        
                                         */

                                        //cadastrarChamado();

                        } else {
                            Toast.makeText(AbrirChamadoActivity.this, "Preencha a descrição!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(AbrirChamadoActivity.this, "Escolha o tipo do problema!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AbrirChamadoActivity.this, "Preencha o título!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    /*
    public void cadastrarChamado(View view){
        
        chamado = new Chamado();
        chamado.setTitulo(campoTitulo.getText().toString());
        chamado.setTipo(campoTipo.getSelectedItem().toString());
        chamado.setDescricaoCli(campoDescricao.getText().toString());

        chamado.salvar();

        Toast.makeText(AbrirChamadoActivity.this, "Chamado enviado!", Toast.LENGTH_SHORT).show();
        finish();
        
    }
 */

    private void carregarDadosSpinner(){

        String[] tipos = getResources().getStringArray(R.array.tipos);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tipos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        campoTipo.setAdapter(adapter);

    }

    public void btVoltar (View view){
        finish();
    }


    

    //Spinner spinner = (Spinner) findViewById(R.id.spinnerTipo);



}
